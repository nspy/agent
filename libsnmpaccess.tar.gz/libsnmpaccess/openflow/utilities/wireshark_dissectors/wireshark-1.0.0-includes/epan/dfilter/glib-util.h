/* $Id: glib-util.h 3992 2008-06-10 03:13:11Z dgu $ */

char*
g_substrdup(const char *s, int start, int len);
