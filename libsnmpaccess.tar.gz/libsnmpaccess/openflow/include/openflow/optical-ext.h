
#ifndef OPENFLOW_OPTICAL_EXT
#define OPENFLOW_OPTICAL_EXT 1

#include "openflow/openflow.h"

/** OpenFlow Optical Extensions **/

#define OOE_VENDOR_ID 0x41445641

enum ooe_type
{
#if 0
    OOE_SWITCH_FEATURES_REQUEST,
    OOE_SWITCH_FEATURES_REPLY,
#endif

    OOE_SWITCH_CONSTRAINTS_REQUEST,
    OOE_SWITCH_CONSTRAINTS_REPLY,

    OOE_POWER_EQ_REQUEST,

    OOE_MGMT_INFO_REQUEST,
    OOE_MGMT_INFO_REPLY,


};

/** generic OOE header **/
struct ooe_header {
    /** Usual OpenFlow header **/
    struct ofp_header   header;
    /** OOE_VENDOR_ID **/
    uint32_t            vendor;
    /** one of the 'ooe_type' **/
    uint32_t            type;
    /** payload **/
    uint8_t             data[0];
};
OFP_ASSERT(sizeof(struct ooe_header) == 16);

#if 0
struct ooe_switch_features {
    uint64_t datapath_id;
    struct ofp_phy_cport ports[0];
};
OFP_ASSERT(sizeof(struct ooe_switch_features) == 8);
#endif

/** port level switching constraints **/
struct ooe_port_constraints {
    /** considered port number **/
    uint16_t port_no;
    /** number of reachable ports **/
    uint16_t num;
    /** array of ports **/
    uint16_t ports[0];
};
OFP_ASSERT(sizeof(struct ooe_port_constraints) == 4);

/** switch level switching constraints **/
struct ooe_switch_constraints {
    struct ooe_header header;
    /** datapathid **/
    uint64_t dpid;
    /** number of per port switching constraints **/
    uint32_t num;
    /** pad to align to a mulitple of 8 bytes **/
    uint32_t pad;
    /** array of port constraints **/
    struct ooe_port_constraints portc[0];
};
OFP_ASSERT(sizeof(struct ooe_switch_constraints) == 32);

/** power equalization request (note it is unidirectional!)**/
struct ooe_power_eq {
    struct ooe_header header;
    /** port number of the starting port **/
    uint16_t    in_port;
    /** port number of the terminating port **/
    uint16_t    out_port;
    /** frequency in GHz **/
    uint32_t    freq;
};
OFP_ASSERT(sizeof(struct ooe_power_eq) == 24);

/** management info extensions **/
struct ooe_mgmt_info {
    struct ooe_header header;
    /** datapathid **/
    uint64_t    dpid;
    /** address of the SNMP agent **/
    uint32_t    snmp_ip;
    /** port number of the SNMP agent **/
    uint16_t    snmp_port;
    /** align to a mulitple of 8 bytes **/
    uint8_t     pad;
    /** number of bytes in 'snmp_community' array **/
    uint8_t     num;
    /** array of bytes **/
    uint8_t     snmp_community[0];
};
OFP_ASSERT(sizeof(struct ooe_mgmt_info) == 32);


#endif
