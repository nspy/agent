#include "src/uthash.h"
#include "flow_insert.h"

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <winsock.h>
#include <winsock2.h>
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <netdb.h>

struct my_struct *users = NULL;

int main(int argc, char *argv[]) {

    int ckt_id=0, in_port=0, out_port=0;
    uint64_t lamda;


    printf("enter details \n");
    printf("circuit id:");
    gets(in); ckt_id = atoi(in);

    prints("inport:");
    gets(in); in_port = atoi(in);
    printf("outport:");
    gets(in); out_port = atoi(in);

    printf("wavelength:");
    gets(in); lambda = (uint64_t) (in);

    if(!(isdigit(in_port) && isdigit(out_port)) ) {
        printf ("enter intergers");
        exit(0);
    }

  add_user (ckt_id, in_port, out_port, lambda);


}
