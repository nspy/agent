#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <fcntl.h>

#define PORT 5025
#define MAXSIZE 1024
#define MAX_NAME_LEN 1024

int socket_fd;

struct crossFlow {
    int in_port;
    int out_port;
    int wavelength;
};

typedef struct crossFlow XCflow;

struct powerstats {
    int port_no;
    //uint8_t pad[6];          /* Align to 64-bits. */
    int pmonset_lambda;
    int pmonset_offset;
    int pmonset_atime;

    uint32_t mes_pmon;

    int voaset_mode;
    int voaset_level;
    int voaset_ref;

    int port_alarms;
};

typedef struct powerstats ps;
/*********this is the dictionary for TL1 command parsing **********/

typedef enum { FORWARD, REVERSE } Dir;

typedef struct {
    char cmd_name[MAX_NAME_LEN+1];
    char cmd[MAX_NAME_LEN+1];
} TL1_dict;

struct listNode {
    TL1_dict data;
    struct listNode *prev;
    struct listNode *next;
};

struct listNode *newNode(const TL1_dict *v);

char* itoa(int val, int base);


//insert dictionary elements
void insert(struct listNode *head, struct listNode *p) ;

//traverse over the linked list based on direction and print
void showList(const struct listNode *p, Dir dir) ;

void deleteList(struct listNode *head) ;

//parse single commands
int parseSingleCmd (char * cmd);

//parsing power cmds
struct powerstats * parseStatsCmd (int portnum, int dir);

//parse cflowmod
int parseFlowCmd (struct crossFlow *cf1, char * cmd);

//browse dictionary
const char * fetchCmd(struct listnode * p, char * cmd);
/*********end of dictionary for TL1 command parsing **********/

//parse commands and process for proper output
char *parseTl1Cmd(char * cmd_name, char * cmd);

//trim cmd output based on TL1 expected output
char * trim_cmd_output(char * buffer);

//get commands from the text file
struct listNode *getCommands ();

//connect to telnet socket and process command
struct listNode * TL1_Channel_Callback (char * tl1ip, char * tl1port, char * file_path);

//
void createCmdDict(char buffer[], int buffer_size, char cmd_name[MAX_NAME_LEN+1]);
