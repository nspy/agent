#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
//#include <winsock.h>
//#include <winsock2.h>

#include "src/uthash.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

struct flowtbl_struct {
    int ckt_id;  /* key */
    int in_port;
    uint64_t lambda;
    int out_port;
    UT_hash_handle hh;         /* makes this structure hashable */
};


void add_user(int ckt_id, int in_port, int out_port, uint64_t lambda) {
    struct my_struct *s;
    HASH_FIND_INT(users, &ckt_id, s);  /* id already in the hash? */
    if (s==NULL) {
      s = (struct my_struct*)malloc(sizeof(struct my_struct));
      s->id = ckt_id;
      HASH_ADD_INT( users, id, s );  /* id: name of key field */
    }
    strcpy(s->name, name);
}

void delete_user(struct my_struct *user) {
    HASH_DEL( users, user);  /* user: pointer to deletee */
    free(user);
}


