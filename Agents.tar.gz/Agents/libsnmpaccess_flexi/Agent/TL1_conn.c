#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <fcntl.h>
#include <stdbool.h>


#define DBG(a, b...) fprintf(stderr, "AGENT: "a"\r\n", ##b)

#define PORT 5025
#define MAXSIZE 1024
#define MAX_NAME_LEN 1024

int socket_fd;
struct crossFlow {
    int in_port;
    int out_port;
    int wavelength;
};

struct crossFlow cf;

struct powerstats {
    int port_no;
    //uint8_t pad[6];          /* Align to 64-bits. */
    int pmonset_lambda;
    int pmonset_offset;
    int pmonset_atime;

    uint32_t mes_pmon;

    int voaset_mode;
    int voaset_level;
    int voaset_ref;

    int port_alarms;
};
typedef struct powerstats ps;

char* itoa(int val, int base){

	static char buf[32] = {0};

	int i = 30;

	for(; val && i ; --i, val /= base)

		buf[i] = "0123456789abcdef"[val % base];

	return &buf[i+1];

}


/*********this is the dictionary for TL1 command parsing **********/

char * trim_cmd_output(char * buffer);
bool trim_single_cmd(char * buffer, char * cmd);

typedef enum { FORWARD, REVERSE } Dir;

typedef struct {
    char cmd_name[MAX_NAME_LEN+1];
    char cmd[MAX_NAME_LEN+1];
} TL1_dict;

struct listNode {
    TL1_dict data;
    struct listNode *prev;
    struct listNode *next;
};

struct listNode *newNode(const TL1_dict *v) {
    struct listNode *p = calloc(1,sizeof(struct listNode));
    assert(p != NULL);
    p->data = *v;
    p->next = p->prev = NULL;
    return p;
};

//insert dictionary elements
void insert(struct listNode *head, struct listNode *p) {
    struct listNode *q = head;

    //while ((q->next != NULL) && (p->data.cmd > q->next->data.cmd)) {
    while ((q->next != NULL)) {
        q = q->next;
    }

    p->next = q->next;
    if (q->next != NULL) {
        q->next->prev = p;
    }

    q->next = p;
    p->prev = q;
}

//traverse over the linked list based on direction and print
void showList(const struct listNode *p, Dir dir) {
    const struct listNode *q = p;

    //printf("Dict List (cmd_name:execcmd) : ");
    if (q != NULL) {
        while (q != NULL) {
            printf("{ %s, %s } ", q->data.cmd_name, q->data.cmd);
            if (dir == FORWARD) {
                q = q->next;
            } else {
                q = q->prev;
            }
        }
    } else {
        puts(" (empty) ");
    }
    puts("");
}

void deleteList(struct listNode *head) {
    struct listNode *p = head, *q;
    while (p != NULL) {
        q = p->next;
        free(p);
        p = q;
    }
}

//parse TL1 command output
char *
parseTl1Cmd(char * cmd_name, char * cmd) {
    char * token;
    char * array[1024];
    int i=0;int tmp_char2int;

    if (!strcmp(cmd_name, "switch_size"))
    {
        token = strtok(cmd, "=");
        while (token != NULL)
        {
            array[i++] = token;
            token = strtok(NULL, ",");
        }

        tmp_char2int = atoi(array[1]);
        tmp_char2int = tmp_char2int * 2;
        printf("a:%s b*:%s c:%d \n",array[0], itoa(tmp_char2int,10), tmp_char2int);
        return( itoa(tmp_char2int,10) );
    }
    else if (!strcmp(cmd_name, "sr_no"))
    {
          token = strtok(cmd, "=");
        while (token != NULL)
        {
            array[i++] = token;
            token = strtok(NULL, ",");
        }
           printf("a:%s b*:%s c:%d \n",array[0], array[1]);
           return(array[1]);
    }
    else if (!strcmp(cmd_name, "attenuate"))
    {
          token = strtok(cmd, "=");
        while (token != NULL)
        {
            array[i++] = token;
            token = strtok(NULL, ",");
        }
           if(strcmp(array[1],"converged"))
            return(array[1]);
           else
            return (NULL);
    }

}//end of parseTl1Cmd


const char * fetchCmd(struct listnode * p, char * cmd) {
    struct listNode *q = p;
    char cmd_output[1024] ;

    if (q != NULL) {
        while (q != NULL) {
            printf("searching in pair %s with %s cmd :%s\n", q->data.cmd_name, cmd, q->data.cmd);
            if (!(strcmp(q->data.cmd_name,cmd))) {
                printf("found match");
                strncpy(cmd_output, q->data.cmd, sizeof (q->data.cmd));
                strcpy(cmd_output,parseTl1Cmd(q->data.cmd_name,cmd_output));
                printf("processed match %s", cmd_output);
                break;
            } else {
                q = q->next;
            }
            //q = q->next;
        }//end of while
    }
    //strcpy(cmd,cmd_output);
    return (cmd_output);
}
/*********end of dictionary for TL1 command parsing **********/

//get commands from the text file
struct listNode *getCommands (char * file_path) {

    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    const char s[2] = "$";
    char *token;
    TL1_dict td1;
    struct listNode *head = newNode(&td1), *z;

    //read cmd_name and cmd from files
       fp = fopen(file_path, "r");
       if (fp == NULL)
           exit(EXIT_FAILURE);

       while ((read = getline(&line, &len, fp)) != -1) {

           token = strtok(line, s);
           /*to count only pairs*/
           int count=0;
           /* walk through other tokens */
           while( token != NULL && count <=2)
               {
                  //printf( " token:%s and count :%d\n", token, count );

                if (count == 0)
                   {
                    strcpy(td1.cmd_name,token);
                   }
                else if (count ==1)
                   {
                       strcpy(td1.cmd,token);
                   }

                  count++;
                  token = strtok(NULL, s);

               }
        //form dictionary in format cmd_name:cmd
        insert(head,z = newNode(&td1));

        }//end of upper while

       if (line)
           free(line);

       // use for printing dict
       //showList(head->next, FORWARD);
        return(head->next);
       //exit(EXIT_SUCCESS);

}//end of getCommands

int parseSingleCmd (char * cmd) {

    char buffer[10024]; char * pch;
    int num;
printf("Clientcmd is %s\n",cmd);

    if( !strcmp (cmd, "attenuate") ) {

        strncpy(buffer, "RTRV-EQPT::ATTEN:123:::PARAMETER=CONFIG;", 1024);
    } else if (!strcmp (cmd, "power")) {
        strncpy(buffer,"RTRV-EQPT::PMON:123:::PARAMETER=CONFIG;", 1024);
    }

    if ((send(socket_fd,buffer, strlen(buffer),0))== -1)
        {
         fprintf(stderr, "Failure Sending Message\n");
         close(socket_fd);
         return(0);
        }
    else
        {
        printf("Client:Message being sent: %s\n",buffer);
        int total_size;
        while (1)
        {
            memset(buffer, 0, sizeof(buffer));
            if ((num = recv(socket_fd, buffer, sizeof(buffer), 0)) < 0 )
            {
                break;
                printf("Error with the commands\n");
                return(0);
            }
            else {
                total_size += num;
            }
        }
        /*if ( num <= 0 )
        {
            printf("Error with the commands\n");
            return(0);
        }*/
        buffer[num] = '\0';
      if (strstr(buffer, "COMPLD") || strstr(buffer, "OUTPUT")) pch =1;
       if(pch)
       {
           printf("XC success\n");
       }
       else
       {
           printf("XC Fail\n");
           return(0);
       }

       memset(buffer, '\0', sizeof(buffer));
       return (1);
        }

}//end of parsesinglecmd

struct powerstats * parseStatsCmd (int portnum, int dir)
{

    char buffer[10024]; char * pch;
    ps pssend;
    int num; float tmpf;

    char buff[2048]; char tmpint[100];

    sprintf(tmpint, "%d", portnum);
    if (dir ==1) strcpy(buff,"RTRV-PORT-REVPOWER::");
    else strcpy(buff, "RTRV-PORT-POWER::");
    strcat(buff, tmpint);
    strcat(buff, ":123:;");

    if ((send(socket_fd,buff, strlen(buff),0))== -1)
        {
         fprintf(stderr, "Failure Sending Message\n");
         close(socket_fd);
         return;
        }
    else
        {


        num = recv(socket_fd, buffer, sizeof(buffer), 0);
        if ( num <= 0 )
        {
         printf("Error with the commands\n");
         return(0);
        }

        buffer[num] = '\0';
        memset(buff, 0, sizeof(buff));
        pch = strstr(buffer, "COMPLD");
      if (pch)
      {
            strcat(tmpint, ":");
            char * pch1 = strstr(pch, tmpint);
            strncpy(buff, (pch1+2),5);
            //check for negativeness
            pch = strstr(buff, "-");
            if (!pch)
               {
                tmpf = atof(buff);
                pssend.mes_pmon = *(uint32_t*)&tmpf;
               }
            else
              {
                tmpf = atof(buff);
                pssend.mes_pmon = *(uint32_t*)&tmpf;
              }

      }
       else
       {
           printf("XC Fail\n");
           return;
       }

       memset(buffer, '\0', sizeof(buffer));
       memset(buff, '\0', sizeof(buff));
       return(&pssend);
        }

}//end of parsestatscmd

int parseFlowCmd (struct crossFlow * cf1, char * cmd) {

    int num;char buffer[10024];
    char * pch; char strI[256], strO[256];
    char buff[1024];

    sprintf(strI, "%d", (cf1->in_port));
    sprintf(strO, "%d", (cf1->out_port));

    //memcpy(&cftmp, cf1, sizeof(struct crossFlow));

    if(cf1 = NULL) return(0);
    if (!strcmp(cmd,"flowmod"))
        {
         strcpy(buff,"ENT-PATCH::");
         strcat(buff, strI);
         strcat(buff, ",");
         strcat(buff, strO);
         strcat(buff, ":123:;");
        }
    else if (!strcmp(cmd,"flowdel"))
        {
         strcpy(buff ,"DLT-PATCH::");
         strcat(buff, strI);
         strcat(buff, "&");
         strcat(buff, strO);
         strcat(buff, ":123:;");
        }

    //printf("\n\ncf is:%s\ncommand:%s", cftmp->out_port, cmd);

    //strcat(buff, cf->in_port);


    printf( "sending XC command: %s\n", buff);

    if ((send(socket_fd,buff, strlen(buff),0))== -1)
        {
         fprintf(stderr, "Failure Sending Message\n");
         close(socket_fd);
         exit(1);
        }
    else
        {
        num = recv(socket_fd, buffer, sizeof(buffer), 0);
        if ( num <= 0 )
        {
         printf("Error with the commands\n");
         return(0);
        }
        buffer[num] = '\0';
       //printf("Client:Message rcv: %s\n",buffer);
       if (strstr(buffer, "COMPLD")) pch =1;
       memset(buffer, '\0', sizeof(buffer));
       if(pch)
       {
           printf("XC success\n");
       }
       else
       {
           printf("XC Fail\n");
           return(0);
       }
       return (1);
        }

}//end of parseflowcmd

char * remove_junk (char * token) {
    char *nl;

    nl = strrchr(token, '\r');
        if (nl) *nl = '\0';

    nl = strrchr(token, '\n');
        if (nl) *nl = '\0';



    return(token);
}//end of remove_junk

bool chk_alphanum (char * token) {
    //strcpy(char str[],token);

    char *str = strdup(token);
    //strcpy(str,&token);
    int i=0;

    while (str[i])
    {

        if (isalpha(str[i]) || isdigit(str[i]) || ispunct(str[i]))
         {printf("true\n");return (true);}
        else {printf("false\n");return(false);}
        i++;
    }

}// end of chk_alphanum

bool trim_single_cmd(char * buffer, char * cmd) {

    //char delimiter = {' ', '\n', '\r', '\0'};

    buffer = strstr(buffer, "OPEN");

    if ((buffer) && !strcmp(cmd,"port")) printf("port Open is %s\n", buffer);
    else { printf("Its a DENY %s\n", buffer); return(false);}

    return(true);
}//end of trimsinglecmd

//trim TL! command output
char * trim_cmd_output(char * buffer) {
    char * token, *nl ;
    char send_buffer[1024];
    //char delimiter = {' ', '\n', '\r', '\0'};
    int chk =0;

    buffer = strstr(buffer, "COMPLD");

    if (buffer) printf("found is %s\n", buffer);
    else { printf("Its a DENY %s\n", buffer); return(0);}

    token = strtok(buffer,"\n");


    while(token != NULL)
    {
     char * tmp_token;
     char * token1 = "COMPLD";
     token = remove_junk (token);

     if ((strcmp(token, token1)) && (strcmp(token, ";")) )
     {
         tmp_token = strtok(token,"\" \r");
         //memset(send_buffer, '\0',sizeof send_buffer);
         while (tmp_token != NULL)
         {

         //printf("token tmp now is:%s\n", tmp_token);
             if (chk_alphanum(tmp_token))
             {
                strcpy(send_buffer, tmp_token);
                //strcat(send_buffer, tmp_token);
                //strcat(send_buffer, "|");
             }
         tmp_token = strtok(NULL, "\" \r");

         }
     }

     token = strtok(NULL, "\n");
    }
    if (chk_alphanum(send_buffer)) {

    strcpy(buffer, send_buffer);
    return(buffer);
    }
    else return(NULL);
}//end of trim cmd output


void createCmdDict(char buffer[], int buffer_size, char cmd_name[MAX_NAME_LEN+1]) {

    TL1_dict execmd1;
    struct listNode *head = newNode(&execmd1), *z;

    strncpy(execmd1.cmd,buffer,buffer_size);
    strcpy(execmd1.cmd_name,cmd_name);

    insert(head,z = newNode(&execmd1));
    showList(head->next, FORWARD);

}//end of createCmdDict

struct listNode *
TL1_Channel_Callback (char * tl1ip, char * tl1port, char * file_path ) {

    struct sockaddr_in server_info;
    int num;
    char buffer[10024];
    char *nl, *cmdParsed;
    char buff[1024];
    char bye_sgn[] = {'q', 'u','i','t','\0'};
    struct timeval tv = {0, 0}; // Init to 0 (Or set directly with your values)
    tv.tv_sec = 1;
    tv.tv_usec = 0;

    TL1_dict execmd1;
    struct listNode *head = newNode(&execmd1), *z;


    if ((tl1ip==NULL) || (tl1port==NULL)) {
        fprintf(stderr, "Cannot get IP and Port n");
        exit(1);
    }

    if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0))== -1) {
        fprintf(stderr, "Socket Failure!!\n");
        exit(1);
    }

    //flags = fcntl(socket_fd,F_GETFL,0);
    //assert(flags != -1);
    //fcntl(socket_fd, F_SETFL, flags | O_NONBLOCK);

    // Set The Timeout On Socket RECV
    setsockopt(socket_fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv, sizeof(struct timeval));
    // Set The Timeout On Socket SEND
    setsockopt(socket_fd, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv, sizeof(struct timeval));

    memset(&server_info, 0, sizeof(server_info));
    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(atoi(tl1port));
    server_info.sin_addr.s_addr = inet_addr(tl1ip);

    printf("address:%s & port:%d sendingport:%d", tl1ip, atoi(tl1port), server_info.sin_port);

    if (connect(socket_fd, (struct sockaddr *)&server_info, sizeof(struct sockaddr))<0) {
        //fprintf(stderr, "Connection Failure\n");
        perror("TL1 connect error");
        exit(1);
    }

    struct listNode * runhead = getCommands(file_path);

    while(runhead != NULL) {

        printf("\nClient: Enter Data for Server:%s\n", runhead->data.cmd);
        char buf[1024];
        char buffer_tmp[1024];

        strcpy(buffer,strcat(runhead->data.cmd, "\n"));

        if(strcmp(buffer_tmp, bye_sgn) == 0) {
            printf("quitting");
            exit(1);
        }

        if ((send(socket_fd,buffer, strlen(buffer),0))== -1) {
                fprintf(stderr, "Failure Sending Message\n");
                close(socket_fd);
                exit(1);
        } else {
                printf("Client:Message being sent: %s\n",buffer);
                num = recv(socket_fd, buffer, sizeof(buffer),0);
                if ( num <= 0 )
                {
                        printf("Error with the commands\n");
                        runhead = runhead->next;
                }

                buff[num] = '\0';
                //trim return message by removing new lines & carriage return
                //cmdParsed = malloc(strlen(buffer)+1);
                //memset(&cmdParsed, '\0', sizeof(buffer));
                char * buftemp = strdup(buffer);

                cmdParsed = (trim_cmd_output(buftemp));
               if(cmdParsed!= NULL) {

                    //memset(&buffer[0], 0, sizeof(buffer));
                    if (cmdParsed)
                    {
                        strcpy(execmd1.cmd,cmdParsed);
                        strcpy(execmd1.cmd_name,runhead->data.cmd_name);
                        insert(head,z = newNode(&execmd1));
                    }

                    //showList(head->next, FORWARD);

                    if(runhead->next == NULL) break;
                }

                memset(&buffer[0], 0, sizeof(buffer));
                runhead = runhead->next;

           }
    }
    //close(socket_fd);
    //struct listNode * z1 = malloc(sizeof(struct listNode));
    //z1 = head;
    //fetchCmd(z1, "sr_no");
    //return(z1);
    return(head);


}//End of main

