
#ifndef __AGENT_H__
#define __AGENT_H__

#include <SnmpAccess/SnmpAccess.h>
#include <SnmpAccess/OpenFlow.h>
#include "openflow.h"
#include <SnmpAccess/Vector.h>
#include <libxml/tree.h>
#include <libxml/parser.h>
//#include <sstream>
//#include <fstream>
#include <string.h>

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

//using namespace std;
/****************** flow table hash code *************/
#include <inttypes.h>
#include "uthash/src/uthash.h"

struct flowtbl_struct {
    int ckt_id;  /* key */
    int in_port;
    uint64_t lambda;
    int out_port;
    UT_hash_handle hh;         /* makes this structure hashable */
};

/***************flow table code snippet end*************/
/****************port addition**************************/

struct addports_struct {
    int portnum;  /* key */
    struct ofp_phy_cport * cports;
    UT_hash_handle hh;         /* makes this structure hashable */
};

/*************end of port addition ******************/

/****ckt peer connections***/
typedef struct  {
    uint16_t portnum;
    uint64_t peerdpid;
    uint16_t peerport;
} Fixedpeer;

typedef Fixedpeer* fxPeerPtr1;

/**************port changes ckt***********/
/* Description of a cross connection */
struct ofp_connect_ports {

  uint16_t in_port;               /* OFPP_* ports - real or virtual */
  uint16_t out_port;              /* OFPP_* ports - real or virtual */
  uint8_t  pad[4];                   /* Align to 64 bits */

};
OFP_ASSERT(sizeof(struct ofp_connect_ports) == 8);
/*************port changes ckt*************/


/** The core structure of the Agent **/
typedef struct
{
    /***********************************************************/

    /** SNMP channel configuration **/
    //SNMP_Channel_Conf   SnmpConf;

    /** Address of the TL1 port listener **/
    char                TL1_Port[64];

    /** Address of the TL1 listener **/
    char                TL1_Listen[64];

    /** Address of the OpenFlow controller **/
    char                OpenFlowAddr[64];

    /** Resource database **/
    X_ResourcePtr       Resources;

    /** OpenFlow communication channel **/
    OpenFlow_DriverPtr  OpenFlowDrv;

    /***********************************************************/


    /** System IP / router ID of the Network Element **/
    unsigned int        SysIP;

    /** List of OpenFlow ports **/
    X_ListPtr           Ports;

    //VectorPtr           Constraints;

} X_Core;

typedef X_Core* X_CorePtr;

/**
 * Create X_Core from the configuration stored in a XML file.
 */
X_CorePtr
X_Core_Create_From_File(const char *path);

void
X_Core_Free(X_CorePtr);

void
X_Core_Generate_OpenFlow_Ports(X_CorePtr);

void
X_Core_Handle_Features_Request(X_CorePtr);

void
X_Core_Handle_OpenFlow_Message(X_CorePtr, struct ofp_header*);

void
X_Core_cport_status(X_CorePtr pCore, uint8_t reason,int portnum);

struct ofp_phy_cport*
X_Core_Find_Port(X_CorePtr, X_ModulePtr);

/** Process OOE_MGMT_INFO_REQUEST message **/
void
X_Core_Process_Mgmt_Info_Request(X_CorePtr);

void
XCore_get_cport_stats (struct ofp_cport_stats * ofpstats, int portnum, int dir);

int
sendCommand (char * hostName, int portNum ,char * pMsg);

#define BUF_SIZE 2056



#endif
