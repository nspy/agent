
#include "Agent.h"
#include "byteswap.h"
#include "TL1_conn.h"
//#include "openflow.h"


#define DBG(a, b...) fprintf(stderr, "AGENT: "a"\r\n", ##b)

struct flowtbl_struct *flows = NULL;
struct addports_struct *addports = NULL;

fxPeerPtr1 fxPeerRtrv;
Fixedpeer peerptr[3];
int CKT_ID=0;

/******************************************************************************/

void
SNMP_Channel_Callback(SNMP_ChannelPtr,int, void*);

int
OpenFlow_Driver_Callback(OpenFlow_DriverPtr, OpenFlow_Driver_Callback_Type, struct ofp_header*);

X_CorePtr
X_Core_New(void);

X_CorePtr
X_Core_New_From(X_CorePtr);

void
X_Core_Pre_Init(X_CorePtr pCore);

int
X_Core_Load_From_File(X_CorePtr, const char *);

void error(const char *msg)
{
    perror(msg);
    exit(0);
}

int
sendCommand (char * hostName, int portNum ,char * pMsg);

/******************************************************************************/

int sendCommand (char * hostName, int portNum ,char * pMsg)
{
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[BUF_SIZE];
    DBG("host:%s sending string: %s", hostName, pMsg);
    if (hostName == NULL ) {
       fprintf(stderr,"usage %s hostname port\n", hostName);
       return;
    }
    portno = portNum;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");

    server = gethostbyname(hostName);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        return(0);
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr,
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);

    serv_addr.sin_port = htons(portno);


    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
       {  DBG("error connecting server %s", hostName); return(0);}


    bzero(buffer,BUF_SIZE);
    //fgets(buffer,255,stdin);
    strcpy (buffer, pMsg);
    DBG("sending command %s", buffer);
    n = write(sockfd,buffer,(BUF_SIZE - 1));

    if (n < 0)
         error("ERROR writing to socket");

    bzero(buffer,BUF_SIZE);
    n = read(sockfd,buffer,(BUF_SIZE - 1));

    if (n < 0)
         error("ERROR reading from socket");

    printf("receving from Waveshaper: %s\n",buffer);
    close(sockfd);

    return 0;
}


int
X_Core_Init(X_CorePtr pCore)
{
    if (pCore == NULL)
        return 1;

    /*
    pCore->SnmpChannel = SNMP_Channel_New(&pCore->SnmpConf);

    if (pCore->SnmpChannel == NULL)
        return 1;

    pCore->SnmpTrapHandler = SNMP_TrapHandler_New(pCore->SnmpTrap);

    if (pCore->SnmpTrapHandler == NULL)
        return 1;

    pCore->Resources = X_Resource_New();
    */

    pCore->Ports = X_List_New((X_ListMemFree_t)(free));

    pCore->OpenFlowDrv = OpenFlow_Driver_New();

    OpenFlow_Driver_Set_UserData(pCore->OpenFlowDrv, pCore);
    OpenFlow_Driver_Set_Callback(pCore->OpenFlowDrv, OPENFLOW_DRV_CB_FEATURES_REQ, OpenFlow_Driver_Callback);
    OpenFlow_Driver_Set_Callback(pCore->OpenFlowDrv, OPENFLOW_DRV_CB_MESSAGE, OpenFlow_Driver_Callback);
    OpenFlow_Driver_Set_Callback(pCore->OpenFlowDrv, OPENFLOW_DRV_CB_DISCONNECTED, OpenFlow_Driver_Callback);

    X_Resource_Set_User_Data(pCore->Resources, pCore);

    /*
    X_Resource_Set_SNMP_Channel(pCore->Resources, pCore->SnmpChannel);

    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_READY, SNMP_Channel_Callback);
    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_CONN_CREATED, SNMP_Channel_Callback);
    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_CONN_DESTROYED, SNMP_Channel_Callback);
    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_MOD_CREATED, SNMP_Channel_Callback);
    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_MOD_DESTROYED, SNMP_Channel_Callback);
    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_OL_CREATED, SNMP_Channel_Callback);
    SNMP_Channel_SetCallback(pCore->SnmpChannel, SNMP_CHANNEL_CB_OL_DESTROYED, SNMP_Channel_Callback);

    SNMP_Channel_Set_Context(pCore->SnmpChannel,(void*)pCore);
    */

    OpenFlow_Driver_Start(pCore->OpenFlowDrv);
    OpenFlow_Driver_Connect(pCore->OpenFlowDrv, pCore->OpenFlowAddr);

    return (0);
}

X_CorePtr
X_Core_New(void)
{
    X_CorePtr pCore = (X_CorePtr)(malloc(sizeof(X_Core)));
    if (pCore != NULL)
    {
        X_Core_Pre_Init(pCore);
    }
    return pCore;
}

X_CorePtr
X_Core_New_From(X_CorePtr pCoreConf)
{
    X_CorePtr pCore = X_Core_New();

    /** Copy configuration **/

    memcpy(pCore->TL1_Port, pCoreConf->TL1_Port, sizeof(pCore->TL1_Port));
    memcpy(pCore->TL1_Listen, pCoreConf->TL1_Listen, sizeof(pCore->TL1_Listen));

    memcpy(pCore->OpenFlowAddr, pCoreConf->OpenFlowAddr, sizeof(pCore->OpenFlowAddr));

    /** Now initialize **/
    X_Core_Init(pCore);

    return pCore;
}

void
X_Core_Pre_Init(X_CorePtr pCore)
{
    if (pCore == NULL)
        return;

    strncpy(pCore->TL1_Listen, "137.222.204.55", sizeof(pCore->TL1_Listen));
    strncpy(pCore->OpenFlowAddr, "192.168.1.1:6633",sizeof(pCore->OpenFlowAddr));

    pCore->Resources = NULL;
    pCore->OpenFlowDrv = NULL;

    pCore->SysIP = 0;
    pCore->Ports = NULL;
}

int
X_Core_Load_From_File(X_CorePtr pCore, const char *path)
{
    xmlNodePtr root, node, root_tmp;
    xmlDocPtr doc;
    xmlChar *s;

    if (pCore == NULL || path == NULL)
    {
        return -1;
    }

    ////
    doc = xmlParseFile(path);

    if (doc == NULL)
    {
        return (-1);
    }

    root = xmlDocGetRootElement(doc);

    if (root == NULL)
    {
        xmlFreeDoc(doc);
        return (-1);
    }

    if (xmlStrcasecmp((xmlChar*)"config",root->name))
    {
        xmlFreeDoc(doc);
        return (-1);
    }

    for (node = root->children; node; node = node->next)
    {
        if (node->type != XML_ELEMENT_NODE)
        {
            continue;
        }

        if (!xmlStrcasecmp((xmlChar*) "TL1host",node->name))
        {
            s = xmlNodeGetContent(node);
            strncpy(&pCore->TL1_Listen,(char*) s, sizeof(pCore->TL1_Listen));
            xmlFree(s);
        }
        else if (!xmlStrcasecmp((xmlChar*) "TL1port",node->name))
        {
            s = xmlNodeGetContent(node);
            strncpy(&pCore->TL1_Port,(char*) s, sizeof(pCore->TL1_Port));
            xmlFree(s);
        }
        else if (!xmlStrcasecmp((xmlChar*)"openflow", node->name))
        {
            s = xmlNodeGetContent(node);
            strncpy(pCore->OpenFlowAddr,(char*)s, sizeof(pCore->OpenFlowAddr));
            xmlFree(s);
        }
        else if (!xmlStrcasecmp((xmlChar*)"peers",node->name))
          {
            int i =1;
            for(root = node->children; root != NULL; root=root->next) {
                if(root->type == XML_ELEMENT_NODE) {

                    if(xmlStrcasecmp((xmlChar*)"ports",root->name))
                    {
                        DBG ("XML root name is not ports");
                        return (-1);
                    }

                    for(root_tmp = root->children; root_tmp != NULL; root_tmp=root_tmp->next) {

                        if(root_tmp->type == XML_ELEMENT_NODE) {
                            printf("\nroot_tmp name: %s\n", root_tmp->name);
                            xmlChar * key;

                          if ((!xmlStrcmp(root_tmp->name, (const xmlChar *)"portnum"))) {
                                        key = xmlNodeGetContent(root_tmp);
                                        uint16_t tmp = strtoul( ((char*)key), NULL , 0);
                                        peerptr[i].portnum = tmp;
                                        DBG("output: %hu ",peerptr[i].portnum);
                                        xmlFree(key);
                                    } else if ((!xmlStrcmp(root_tmp->name, (const xmlChar *)"peerdpid"))) {
                                        key = xmlNodeGetContent(root_tmp);
                                        printf("\n&&&&&&&&&&&&&&peer key is: %s\n", key);
                                        uint64_t tmp = strtoull( ((char*)key), NULL , 0);
                                        DBG("nodeid tmp: %llu ",tmp);
                                        //memcpy((void *)&fxPtr1->nodeid,(void*) &tmp,sizeof(tmp));
                                        //fxPtr.nodeid = tmp;
                                        peerptr[i].peerdpid = tmp;
                                        DBG("nodeid: %llu ",peerptr[i].peerdpid);
                                        xmlFree(key);
                                    }  else if ((!xmlStrcmp(root_tmp->name, (const xmlChar *)"peerport"))) {
                                        key = xmlNodeGetContent(root_tmp);
                                        uint16_t tmp = strtoul( ((char*)key), NULL , 0);
                                        peerptr[i].peerport = tmp;
                                        DBG("peerport:%hu ",peerptr[i].peerport);
                                        xmlFree(key);
                                    } else {
                                                DBG ("XML node name not found");
                                                return (-1);
                                            }
                        }

                    } i++; DBG("no of nodes:%d", i);//end of inner for
                }// verify node elements
            }//end of outer for
          } //end of else if peer elements
    }
    fxPeerRtrv = peerptr;
    xmlFreeDoc(doc);

    return (0);
}

/**
 * Create X_Core from the configuration stored in a XML file.
 */
X_CorePtr
X_Core_Create_From_File(const char *path)
{
    X_Core core;
    X_CorePtr pCore;

    X_Core_Pre_Init(&core);

    X_Core_Load_From_File(&core, path);

    pCore = X_Core_New_From(&core);

    return pCore;
}

void
X_Core_Free(X_CorePtr pCore)
{
    if (pCore != NULL)
    {
        return;
    }

   /* if (pCore->SnmpTrapHandler)
    {
        SNMP_TrapHandler_Free(pCore->SnmpTrapHandler);
    }

    if (pCore->SnmpChannel)
    {
        SNMP_Channel_Stop(pCore->SnmpChannel);

        SNMP_Channel_Free(pCore->SnmpChannel);
    }
    */
    if (pCore->Resources)
    {
        X_Resource_Free(pCore->Resources);
    }

    free (pCore);
}

void
X_Core_Generate_OpenFlow_Ports(X_CorePtr pCore)
{
    struct ofp_phy_cport *port;
    X_ListNodePtr pNode;
    X_ResourcePtr pRes;
    int PortBase = 1000;
    unsigned int PeerIP;

    assert (pCore != NULL);

    pRes = pCore->Resources;



        port = malloc(sizeof(struct ofp_phy_cport));

        if (port == NULL)
            printf("port is NULL");

        memset(port, 0, sizeof(struct ofp_phy_cport));

        port->config = htonl((OFPPC_NO_FLOOD | OFPPC_NO_STP | OFPPC_NO_PACKET_IN));
        port->supp_swtype = htons(OFPST_WAVE);

        // TODO:
        // assign bandwidth according to constraints bitmaps from the line port

        X_List_Append(pCore->Ports, port);

    X_List_ForEach(pCore->Ports, pNode)
    {
        port = (struct ofp_phy_cport*)(pNode->Data);

        X_Resource_Printf("Port: %d name = %s", ntohs(port->port_no), (char*)port->name);
        X_Resource_Printf("HW: %x:%x:%x:%x:%x:%x (%08x)",
                port->hw_addr[0],port->hw_addr[1],port->hw_addr[2],
                port->hw_addr[3],port->hw_addr[4],port->hw_addr[5],
                (*(unsigned int*)(port->hw_addr)));
    }
}

void
X_Core_Handle_Features_Request(X_CorePtr pCore)
{
    //X_ListNodePtr pNode;
    struct ofp_switch_features *osf;
    struct ofp_phy_cport *c_opp;
    char tmp[409600];
    char * cmd_output;
    char portName[6] = {'P', 'O','L', '1','-','\0'};
    //char name[16] = { 'M', 'O','D','-','5','-','1','\0'}; /* Null-terminated */
    uint8_t hw_addr[6] = {00, 02, 03, 04, 05, 06};
    size_t len = sizeof(struct ofp_switch_features);
    int i=0,j, jj=0;

    /* Extensions for circuit switch ports */
    uint64_t bandwidth_feq;
    uint16_t peer_port_no = 0;     /* Discovered peer's switchport number */
    uint64_t peer_datapath_id = 0; /* Discovered peer's datapath id */
    uint16_t num_bandwidth = 1;    /* Identifies number of bandwidth array elems */
    uint64_t bandwidth_feq1 = ( 1<<0 | 1<< 1 );
    //bandwidth_feq = htonll( bandwidth_feq1 );
    //uint64_t bandwidth_feq = ( 1<<6 | 1<< 10 | 1<< 11 | 1<< 12 | 1<< 13 );//| \
    //                           1<<14 | 1<< 15 | 1<< 16 | 1<< 17 );   /* supported bandwidth check enum port_1am_bw */

    osf = (struct ofp_switch_features*)tmp;

    /* send details for TL1 command processing for switch_features*/
    struct listNode * Dict_head = malloc(sizeof(struct listNode));
    Dict_head = TL1_Channel_Callback(pCore->TL1_Listen, pCore->TL1_Port,"cmd_maps_TL1.txt");

    unsigned int tmpint; char* pAddr;
    cmd_output = fetchCmd(Dict_head, "sr_no");//fetch serial

    pAddr = strdup(cmd_output);
    char dpid_got[4094];

    strcpy(dpid_got, cmd_output);
    inet_aton(pAddr, (struct in_addr*)&tmpint);

    DBG("printing DPID:%s tmpint:%d", cmd_output, tmpint);
    osf->datapath_id = htobe64 (atoi(cmd_output));//get dapathid from conf file

    osf->n_tables = (1);
    memset( cmd_output, '\0', sizeof(cmd_output) );
    cmd_output = fetchCmd(Dict_head, "switch_size");// cports
    printf("switch size:%s\n", cmd_output);

    osf->n_cports = (atoi(cmd_output));
    int ncports = atoi(cmd_output);

    if (osf->n_cports == 60)
      {    osf->n_cports = 30;
           ncports = 30;
      }

    osf->capabilities = htonl(OFPC_FLOW_STATS | OFPC_TABLE_STATS | \
                              OFPC_PORT_STATS );
    bool power=false, attenuate=false;
    if( (parseSingleCmd("attenuate")) ) attenuate=true;
    if( (parseSingleCmd("power")) ) power=true;
    if( power && attenuate)
        osf->capabilities = htonl(OFPC_FLOW_STATS | OFPC_TABLE_STATS | \
                                  OFPC_PORT_STATS | OFPC_Attenuate | OFPC_Power );
    else if (power)
        osf->capabilities = htonl(OFPC_FLOW_STATS | OFPC_TABLE_STATS | \
                                  OFPC_PORT_STATS | OFPC_Power );
    else
        osf->capabilities = htonl(OFPC_FLOW_STATS | OFPC_TABLE_STATS | \
                                  OFPC_PORT_STATS);

   /* X_List_ForEach(pCore->Ports, pNode)
    {
        opcp = (struct ofp_phy_cport*)pNode->Data;
        memcpy(tmp + len + i * (sizeof(struct ofp_phy_cport)), opcp,
                sizeof(struct ofp_phy_cport));
        i++;
    } */

    c_opp = malloc(sizeof(struct ofp_phy_cport));

    if (ncports == 320 || ncports == 384)
	{
  	 //ncports = 100;
	 //osf->n_cports = 100;
	}
	DBG("ncports: %d \n ", ncports);
    while( i < ncports) {

       int portBase = 0;
       int j;
       char * pch;char buffTemp[3];

        if (c_opp == NULL)
            continue;

        memset(c_opp, 0, sizeof(struct ofp_phy_cport));
        portBase = portBase + i;
        c_opp->port_no = htons(portBase);
        for (j=0; j<6; j++){
         c_opp->hw_addr[j] = hw_addr[j];
        }
        //if (i == 4) portName[3] = 'O'; // hardcoding output port
            //portName[5]= (char) (((int)'0')+i); // set ports
        char * charBase =  itoa(portBase,10);
        portName[3] = charBase[0];
        portName[4] = charBase[1];
        portName[5]= charBase[2]; // set ports
        portName[6] = '\0';
        strncpy(c_opp->name, portName,6);

        c_opp->config = htonl(111);

        char  portStatus[]= "RTRV-PORT-SHUTTER::000&&000:123:;";

        pch = strchr(portStatus, '0');
        j=0;
        sprintf(buffTemp,"%d", portBase);
        //printf("bufftemp:%d \n", strlen(buffTemp));

        if (pch != NULL)
        {
            for(j=0 ; j<strlen(buffTemp);) {

                if (strlen(buffTemp) == 2) {
                    portStatus[(pch-portStatus) + (1 + j)] = buffTemp[j];
                    portStatus[(pch-portStatus) + (6 + j)] = buffTemp[j];
                }
                else if (strlen(buffTemp) == 3) {
                    portStatus[(pch-portStatus)  + j] = buffTemp[j];
                    portStatus[(pch-portStatus) + (5 + j)] = buffTemp[j];
                }
                else {
                    portStatus[(pch-portStatus) + (2 + j)] = buffTemp[j];
                    portStatus[(pch-portStatus) + (7 + j)] = buffTemp[j];
                }
                //printf("bufftemp:%s and j:%c and text:%s\t", buffTemp[j], j, portStatus[(pch-portStatus) + (2 - j)]);
                j++;
            }
        }
        memset( buffTemp, '\0', sizeof(buffTemp));

        //strcpy(sendTmp, portStatus);
        //if( strcmp ((parseSingleCmd(portStatus, "port")), "open") )
        c_opp->state = htonl(222);

        c_opp->curr = htonl(OFPPF_X);
        c_opp->advertised = htonl(OFPPF_OC1 | OFPPF_OTU2 |OFPPF_OC768);
        c_opp->supported = htonl(OFPPF_OC3 | OFPPF_100GB | OFPPF_OTU1);
        c_opp->peer = htonl(OFPPF_X);

        c_opp->supp_sw_tdm_gran = 0;
        c_opp->supp_swtype = htons(OFPST_FIBER);
    //    if (i == 2 & !strcmp(pCore->SnmpConf.Host, "101"))
          jj=0;
          if (i == peerptr[1].portnum) jj=1;
          else if (i == peerptr[2].portnum) jj =2;
          else if (i == peerptr[3].portnum) jj=3;
          if (jj > 0) {
            c_opp->peer_port_no = htons(peerptr[jj].peerport);
            c_opp->peer_datapath_id = htobe64(peerptr[jj].peerdpid);
            DBG("\n\n############ peerport in: %d and dpid %d", peerptr[jj].peerport, peerptr[jj].peerdpid);
         } else {
              c_opp->peer_port_no = 0;
              c_opp->peer_datapath_id =0;
         }



        c_opp->num_bandwidth = htons(num_bandwidth);

        //DBG("copp: %llu sizebwfeq:%d size:%d \n", c_opp->bandwidth, sizeof(bandwidth_feq), sizeof(&c_opp->port_no));
        //memset(c_opp->bandwidth, 0, sizeof(bandwidth_feq));
        c_opp->bandwidth = 1;

        //DBG("sizebwfeq %d and sizecopp: %d and bandwidth:%" PRIu64 "\n", sizeof(bandwidth_feq), sizeof(&c_opp->bandwidth), c_opp->bandwidth);
        //DBG("sizebwfeq %d and sizecopp: %d and bandwidth: %llu", sizeof(bandwidth_feq), sizeof(&c_opp->bandwidth), c_opp->bandwidth);
        /*DBG("DPID is :%s \n"
            "port_name is :%s \n"
            "port num is:%u \n"
            "features is :%lu\n", dpid_got, portName, portBase, c_opp->curr);*/

        // prints all the details the Agent send in the features reply message
    if (i >1)
        printf("\n ofp_phy_cport:port_num=<%d>\n"

            "\n ofp_phy_cport:hw_addr=<%d>\n"

            "\n ofp_phy_cport:namee=<%s>\n"

            "\n ofp_phy_cport:configg=<%d>\n"

            "\n ofp_phy_cport:supported=<%d>\n"

            "\n ofp_phy_cport:statee=<%d>\n"

            "\n ofp_phy_cport:currr=<%d>\n"

            "\n ofp_phy_cport:cpeerport=<%x>\n"

            "\n ofp_phy_cport:advertisedd=<%d>\n"

            "\n ofp_phy_cport:sw_type=<%d>\n"

            "\n ofp_phy_cport:bandwidth=<%d>\n"

            "\n ofp_phy_cport:sizeofcport=<%d>\n"

            "\n ofp_phy_cport:numbw=<%d>\n\n",

            c_opp->port_no, c_opp->hw_addr, c_opp->name, c_opp->config, c_opp->state,

            c_opp->curr, c_opp->advertised, c_opp->supported, c_opp->peer_port_no,

            c_opp->supp_swtype, (c_opp->bandwidth), sizeof(&c_opp), c_opp->num_bandwidth);


        //memcpy(tmp +len + i * (sizeof(struct ofp_phy_cport)) , c_opp, sizeof (struct ofp_phy_cport));
        /* WE HAVE TO CALCULATE THIS. DEPENDS ON THE SIZE OF BANDWIDTH LIST!!!*/

        memcpy(tmp +len + i*(sizeof(struct ofp_phy_cport)), c_opp, (sizeof (struct ofp_phy_cport)) );

        //opcp = (struct ofp_phy_cport *)osf->cports[i];
        //memcpy(opcp , c_opp, sizeof (struct ofp_phy_cport));

	//   int bw[64];
	//   int64_to_bin_array(*c_opp->bandwidth, bw, 64);

    /*    unsigned int j, k;

        printf("\nj\t");
	 // print the bits
        for (k = 0; k < 64; k++) {
            uint64_t x = (uint64_t)((uint64_t)1 << (uint64_t)k);
            if((c_opp->bandwidth[j] & (x)) != 0) {
                printf("1");
            } else {
                printf("0");
            }
        } */
        struct ofp_phy_cport * tmpports = (struct ofp_phy_cport *) malloc (sizeof(struct ofp_phy_cport));
        *tmpports = *c_opp;
        //memcpy (tmpports, c_opp, sizeof(struct ofp_phy_cport));
        add_ports (i, tmpports);
        i++;

    }//end of while for ports

    len += (ncports) * (sizeof(struct ofp_phy_cport));

    //osf->n_cports = (X_List_Size(pCore->Ports));

    osf->header.type = OFPT_FEATURES_REPLY;
    osf->header.length = htons(len);
    osf->header.version = OFP_VERSION;
    osf->header.xid = htonl(11);

    DBG("ncports: %x \n sizeof:%d len:%d", ntohs(osf->n_cports), sizeof(osf), len);

    _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv, (char*)osf, len);
}

/* Converts from an unsigned long long into an array of
integers that form the binary representation of a */
void int64_to_bin_array(uint64_t a, int *b, int length)
{
   int i;
printf("xaxax");
   for(i = 0; i < length; i++)
   {
      *(b+i) = (a >> i) & 1; //store the ith bit in b[i]
	printf ("int=%d  bit=%d", i, b);
   }

}

/* prints a one-dimensional array given
   a pointer to it, and its length */
void printArray(int *arr, int length)
{
   int i;
   for(i = 0; i < length; i++)
   {
      printf("bit: %d ", *(arr + i));
   }
   printf("\n\n");
}

void
X_Core_Handle_OpenFlow_Message(X_CorePtr pCore, struct ofp_header *pMsg)
{
    struct ofp_vendor_header *ofv;
    struct ofp_error_msg err;
    struct ooe_header* ooe_hdr;
    struct ofp_stats_request *ofs;
    struct ofp_cport_stats cport_stats;
    struct ofp_cflow_mod *cflow_mod;
    //uint16_t wildcards = htons(OFPCW_IN_WPORT|OFPCW_OUT_WPORT);
    uint16_t wildcards = (OFPCW_IN_PORT|OFPCW_OUT_PORT|OFPCW_IN_TPORT|OFPCW_OUT_TPORT);
    size_t freq = 0;
    struct ofp_wave_port in, out, *pwave;
    X_ListNodePtr pNode;

    if(pMsg->type != 13) DBG("Received OF Msg type: %d and actual:%x",pMsg->type, pMsg->type);

    if (pMsg->type == OFPT_VENDOR)
    {
        ofv = (struct ofp_vendor_header*) (pMsg);

        if (ntohl(ofv->vendor) == OOE_VENDOR_ID)
        {
            ooe_hdr = (struct ooe_header*)(pMsg);

             if (ntohl(ooe_hdr->type) == OOE_MGMT_INFO_REQUEST)
            {
                X_Core_Process_Mgmt_Info_Request(pCore);
                return;
            }

        }

        err.header.type = OFPT_ERROR;
        err.header.xid = ofv->header.xid;
        err.header.version = OFP_VERSION;
        err.header.length = htons(sizeof(struct ofp_error_msg));

        err.type = htons(OFPET_BAD_REQUEST);
        err.code = htons(OFPBRC_BAD_VENDOR);
        _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv,(char*)&err,sizeof(err));

        return;
    }

    if (pMsg->type == OFPT_STATS_REQUEST)
    {
        ofs = (struct ofp_stats_request*) (pMsg);


        if (ntohs(ofs->type) == OFPST_CPORT)
        {
            struct ofp_cport_stats_request * cpsr = (struct ofp_cport_stats_request*)(ofs->body);
            char Msg[256];
            struct ofp_stats_reply * ofpstats_reply;
            //struct ofp_port_stats_request * cpsr = (struct ofp_port_stats_request*)(ofs->body);
            ofpstats_reply = (struct ofp_stats_reply *)Msg;
            memset(Msg, 0 ,sizeof(Msg));

            //////////struct ofp_stats_reply * ofpstats_reply = malloc( sizeof (struct ofp_stats_reply )  );

            ofpstats_reply->header.length = htons((sizeof(struct ofp_stats_reply)) +32);
            ofpstats_reply->header.type = OFPT_STATS_REPLY;
            ofpstats_reply->header.xid = ofs->header.xid;
            ofpstats_reply->header.version = OFP_VERSION;
            //ofpstats_reply.header.length = htons(sizeof(struct ofp_port_stats));

            ofpstats_reply->type = htons(OFPT_CPORT_MOD);
            ofpstats_reply->flags = htons(2);
            //ofpstats_reply->body[0] = 12;

            struct ofp_cport_stats * ofpcportstats_ptr = (struct ofp_cport_stats *)ofpstats_reply->body;
            XCore_get_cport_stats (ofpcportstats_ptr, (cpsr->port_no), ntohs(cpsr->direction));

            _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv,(char*)Msg, ntohs(ofpstats_reply->header.length) );

        return;
       }
     }//end of OFPT_STATS_REQUEST

    if (pMsg->type == 18)
     {
        struct ofp_header bar_header;
        bar_header.type = OFPT_BARRIER_REPLY;
        ++pMsg->xid;
        bar_header.xid = htonl (10001);
        DBG("add msg xid:%lu",err.header.xid);
        bar_header.version = 0x01;
        bar_header.length = htons(sizeof(struct ofp_header));

        _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv,(char*)&bar_header,sizeof(bar_header));
     }

     if (pMsg->type == 255 || pMsg->type == 22)
    {
        cflow_mod = (struct ofp_cflow_mod*)pMsg;
        DBG("unpacking wildcard:%010x and pMsg:%010x \n", (wildcards), cflow_mod->connect.wildcards);

        if (cflow_mod == NULL)
            return;

        if (cflow_mod->command != htons(OFPFC_ADD) &&
                cflow_mod->command != htons(OFPFC_DELETE))
        {

            return;
        }

        if(cflow_mod->connect.wildcards != wildcards)
        {
            //return;
        }


    DBG("inportsize:%d and contd:%d:\n", ntohl(cflow_mod->connect.in_port), ntohs(cflow_mod->connect.out_port));
    uint16_t inwport, outwport;
    inwport = cflow_mod->connect.in_port;
    outwport = cflow_mod->connect.out_port;
    //uint64_t bwport = cflow_mod->connect.bandwidth;
    //DBG("inport:%d and outport:%d and bandwidth:%llu\n", ntohs(inwport), ntohs(outwport), htobe64(bwport));
    DBG("inport:%d and outport:%d \n", ntohs(inwport), ntohs(outwport));

	/*pwave = (struct ofp_wave_port*)&cflow_mod->connect.in_port;

        memcpy(&in, pwave, sizeof(in));

        pwave += 1;

        memcpy(&out, pwave, sizeof(out));*/

        //DBG("inport:%d \n", ntohs(cflow_mod->connect.in_port[0]));
        /*printf("IN: %d OUT: %d\n", ntohs(in.wport), ntohs(out.wport));

        struct ofp_phy_cport *port_in = NULL, *port_out = NULL, *ofport;

        X_List_ForEach(pCore->Ports, pNode)
        {
            ofport = (struct ofp_phy_cport*)(pNode->Data);

            if (ofport->port_no == inwport)
            {
                port_in = ofport;
            }
            else if (ofport->port_no == outwport)
            {
                port_out = ofport;
            }

            if (port_in && port_out)
                break;
        }

        if (!port_in || !port_out)
        {
            printf("Wrong port!?\n");
        }*/

/****************************TL1 setup************************************************/

          //in.wavelength = ntohl(in.wavelength);
          //DBG("inport: %d, outport:%d, bandwidth: %llu", ntohs(in.wport), ntohs(out.wport), (in.wavelength));

          struct crossFlow * sendCF;
          XCflow XCFlow;
          sendCF = &XCFlow;
          //cf = malloc(sizeof(struct crossFlow));
          //DBG( "sending XC command agt:%s", (char)(ntohs(inwport)) );
          int inport =  ntohs(inwport);
          int outport = ntohs(outwport);
          XCFlow.in_port = (char*)inport;
          XCFlow.out_port = (char*)outport;

          //sendCF->out_port = (char)ntohs(outwport);
          //memcpy(sendCF->in_port, (ntohs(inwport)), sizeof(inwport));
          //memcpy(sendCF->out_port, (ntohs(outwport)), sizeof(outwport));
          //sendCF->wavelength = 333;
       if (cflow_mod->command == htons(OFPFC_ADD))
       {
          if (parseFlowCmd(&XCFlow, "flowmod"))
             {
                 printf("success flow mod\n");
                 X_Core_cport_status(pCore, OFPPR_ADD, inport);
                 //X_Core_cport_status(pCore, OFPPR_ADD, outport);
                 add_flows( ntohs(inwport), ntohs(outwport), 0 );
             }
         else
             {
                DBG("Add but not flowmod. Polatis XC connection Failed");
                struct ofp_header bar_header;
                bar_header.type = OFPT_BARRIER_REPLY;

                bar_header.xid = (pMsg->xid);
                bar_header.version = 0x01;
                bar_header.length = htons(sizeof(struct ofp_header));

                _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv,(char*)&bar_header,sizeof(bar_header));
                //return;
              }
       }
       else
       {
           if (parseFlowCmd(&XCFlow, "flowdel"))
             {
                 printf("success Delete flow \n");
                 //X_Core_cport_status(pCore, OFPPR_ADD, outport);
                 del_flows( ntohs(inwport), ntohs(outwport), 0 );
             }
         else
             {
                DBG("Flowdel. Polatis XC connection Failed");
                //return;
              }
       }
/****************************TL1 setup************************************************/

    }

}
/*****************add ports*******************/
void add_ports(int portnum, struct ofp_phy_cport * cports) {
    struct addports_struct *s;

    HASH_FIND_INT(addports, &portnum, s);  /* portnum already in the hash? */
    if (s==NULL) {
      s = (struct addports_struct*)malloc(sizeof(struct addports_struct));
      s->portnum = portnum;
      s->cports = cports;

      HASH_ADD_INT( addports, portnum, s );  /* portnum: name of key field */

      //print_all_ports();
    }
}

void print_all_ports() {
    struct addports_struct *s;
    unsigned int num_ports;
    struct ofp_phy_cport * tmp_copp;

    num_ports = HASH_COUNT(addports);
    printf("There are %u ports\n", num_ports);

    for(s=addports; s != NULL; s=(s->hh.next)) {
        tmp_copp = s->cports;
        printf("portnum:%d, name:%s\n",  s->portnum, tmp_copp->name);
    }
}

struct ofp_phy_cport * find_cport (int port_id) {
    struct addports_struct *s;

        HASH_FIND_INT(addports, &port_id, s);  /* id already in the hash? */
        if (s->cports !=NULL)
        {
           /* printf("\n ofp_phy_cport:port_num=<%d>\n"

            "\n ofp_phy_cport:hw_addr=<%d>\n"

            "\n ofp_phy_cport:namee=<%s>\n"

            "\n ofp_phy_cport:configg=<%d>\n"

            "\n ofp_phy_cport:supported=<%d>\n"

            "\n ofp_phy_cport:statee=<%d>\n"

            "\n ofp_phy_cport:currr=<%d>\n"

            "\n ofp_phy_cport:cpeer=<%d>\n"

            "\n ofp_phy_cport:advertisedd=<%d>\n"

            "\n ofp_phy_cport:sw_type=<%d>\n"

            "\n ofp_phy_cport:peer_dpid=<%d>\n"

            "\n ofp_phy_cport:numbandwidth=<%d>\n"

            "\n ofp_phy_cport:ebandwidth=<%d>\n"

            "\n ofp_phy_cport:sizeof=<%d>\n\n",

            s->cports->port_no, s->cports->hw_addr, s->cports->name, s->cports->config, s->cports->state,

            s->cports->curr, s->cports->advertised, s->cports->supported, s->cports->peer,

            s->cports->supp_swtype, s->cports->peer_datapath_id, s->cports->num_bandwidth, sizeof(s->cports->bandwidth), sizeof(&s->cports));*/
            return (s->cports);
        }
        else { DBG("\n cant find ports in find_ports\n"); return; }
}

/*******************end of add ports*************/

/*****flow table hash snippet****/

void add_flows(int in_port, int out_port, uint64_t lambda) {
    struct flowtbl_struct *s;
    int check =0;

    HASH_FIND_INT(flows, &CKT_ID, s);  /* id already in the hash? */
    for(s=flows; s != NULL; s=(struct flowtbl_struct*)(s->hh.next))
      {

        if(s->in_port == in_port && s->out_port == out_port)
        {
            //printf("Flow Already Exists ckt_id:%d, in:%d, out:%d, lambda:%" PRIu64 "\n", \
            //   s->ckt_id, s->in_port, s->out_port,s->lambda);
            check =1;
             print_all_flows();
        }
        else
        {
            printf("installing Flow");
        }

     }

    if (s==NULL && check ==0)
    {
      CKT_ID++;
      s = (struct flowtbl_struct*)malloc(sizeof(struct flowtbl_struct));
      s->ckt_id = CKT_ID;
      s->in_port = in_port;
      s->out_port = out_port;
      s->lambda = lambda;

      HASH_ADD_INT( flows, ckt_id, s );  /* id: name of key field */
      print_all_flows();
    }

}

void print_all_flows() {
    struct flowtbl_struct *s;
    unsigned int num_flows;

    num_flows = HASH_COUNT(flows);
    printf("There are %u flows\n", num_flows);

    for(s=flows; s != NULL; s=(struct flowtbl_struct*)(s->hh.next)) {
        printf("ckt_id:%d, in:%d, out:%d, lambda:%" PRIu64 "\n", \
               s->ckt_id, s->in_port, s->out_port,s->lambda);
    }
}

void del_flows(int in_port, int out_port, uint64_t lambda) {
    struct flowtbl_struct *s;
    struct flowtbl_struct *s1;
    CKT_ID++;
    int check =0;

    for(s=flows; s != NULL; s=(struct flowtbl_struct*)(s->hh.next))
     {
        if(s->in_port == in_port && s->out_port == out_port)
        {
            check = s->ckt_id;
            printf("deleting id %u flows\n", check);
            HASH_FIND_INT(flows, &check, s1);
            HASH_DEL( flows, s);
            free(s1);
            print_all_flows();
            return;
        }

     }

}

void print_flow (int ckt_id) {
    struct flowtbl_struct *s;
    HASH_FIND_INT(flows, &ckt_id, s);  /* id already in the hash? */
    printf("ckt_id:%d, in:%d, out:%d, lambda:" PRIu64 "\n", \
               s->ckt_id, s->in_port, s->out_port,s->lambda);
}

void delete_user(struct flowtbl_struct *flow) {
    HASH_DEL( flows, flow);  /* flow: pointer to deletee */
    free(flow);
}

/********flow table end*********/

/**************send cport status*************/

void
X_Core_cport_status(X_CorePtr pCore, uint8_t reason, int portnum)
{
    struct ofp_cport_status *cps;
    struct ofp_phy_cport *opcp, *c_opp;
    size_t len = sizeof(struct ofp_cport_status);
    X_ListNodePtr pNode;
    char tmp[4096];
    int i;

    assert(pCore != NULL);

    if(pCore == NULL) return;

    cps = (struct ofp_cport_status*)tmp;
    memset(tmp, 0, sizeof(tmp));

    cps->reason = reason;

    i=0;

    opcp = find_cport(portnum);
    cps->header.type = 0x16; //OFPT_CPORT_STATUS;
    cps->header.length = htons(len);
    cps->header.version = OFP_VERSION;
    cps->header.xid = htonl(11);
    cps->desc = *opcp;

    _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv, (char*)cps, len);

}

/**************sent cport status*************/

/************construct cport stats**********/

void
XCore_get_cport_stats (struct ofp_cport_stats * ofpstats, int portnum, int dir)
{
    struct powerstats * ps = parseStatsCmd(portnum, dir);
    if (ps) {
    ofpstats->mes_pmon = ps->mes_pmon;
    ofpstats->voaset_level = ps->voaset_level;
    }


}//end of get_port_stats
/*************end of cport stats************/





struct ofp_phy_cport*
X_Core_Find_Port(X_CorePtr pCore, X_ModulePtr pMod)
{
    X_ListNodePtr               pNode;
    struct ofp_phy_cport*       pPort;

    if (pCore == NULL || pMod == NULL)
        return NULL;

    X_List_ForEach(pCore->Ports, pNode)
    {
        pPort = (struct ofp_phy_cport*)(pNode->Data);

        if (pMod->Index == *(unsigned int*)pPort->hw_addr)
            return pPort;
    }
    return NULL;
}


void
X_Core_Process_Mgmt_Info_Request(X_CorePtr pCore)
{
    char                        Msg[256];
    struct ooe_mgmt_info*       MgmtInfo;
    //char*                       pAddr;
    char*                       pIpStr;
    char*                       pPortStr;
    unsigned int                addr;

    assert(pCore != NULL);

    if (pCore == NULL)
        return;

    pIpStr = pCore->TL1_Listen;
    pPortStr = strchr(pCore->TL1_Port, ':');

    if (pPortStr != NULL)
    {
        *pPortStr = 0;
        pPortStr++;
    }

    fprintf(stderr, "PORT = %s\r\n", pPortStr);

    inet_aton(pIpStr, (struct in_addr*)&addr);

    MgmtInfo = (struct ooe_mgmt_info*)Msg;

    memset(Msg, 0, sizeof(Msg));

    MgmtInfo->header.header.type = OFPT_VENDOR;
    MgmtInfo->header.header.xid = 0;
    MgmtInfo->header.header.version = OFP_VERSION;


    MgmtInfo->header.vendor = htonl(OOE_VENDOR_ID);
    MgmtInfo->header.type = htonl(OOE_MGMT_INFO_REPLY);

    MgmtInfo->dpid = _htonll(pCore->SysIP);

    MgmtInfo->TL1_ip = htonl(addr);
    MgmtInfo->TL1_port = (pPortStr != NULL) ? htons(atoi(pPortStr)) : htons(161);

    MgmtInfo->header.header.length = htons(sizeof(struct ooe_mgmt_info));

    _OpenFlow_Driver_Send_Raw(pCore->OpenFlowDrv, (char*)Msg, ntohs(MgmtInfo->header.header.length));
}


/******************************************************************************/

void
SNMP_Channel_Callback(SNMP_ChannelPtr pCh, int type, void *data)
{
    X_CorePtr pCore;
    X_ListNodePtr pNode;
    X_ResourcePtr pRsrc;

    pCore = pCh->Context;

    if (pCore == NULL) return;

    pRsrc = pCore->Resources;

     X_Resource_Lock(pRsrc);

    if (type == SNMP_CHANNEL_CB_READY)
    {
        X_List_ForEach(pCh->Inventory.ShelfList, pNode)
        {
            X_LoadEntityShelf(pRsrc,(EntityShelf*) pNode->Data,X_RES_OPER_CREATE);
        }

        X_List_ForEach(pCh->Inventory.ModuleList, pNode)
        {
            X_LoadEntityModule(pRsrc,(EntityModule*) pNode->Data,X_RES_OPER_CREATE);
        }

        X_List_ForEach(pCh->Inventory.ExtObjList, pNode)
        {
            X_LoadEntityModule(pRsrc,(EntityModule*)pNode->Data, X_RES_OPER_CREATE);
        }

        X_List_ForEach(pCh->Inventory.OLList, pNode)
        {
            X_LoadEntityOL(pRsrc,(EntityOL*) pNode->Data,X_RES_OPER_CREATE);
        }

        X_List_ForEach(pCh->Inventory.ConnectionList, pNode)
        {
            X_LoadEntityConnection(pRsrc,(EntityConnection*) pNode->Data,1);
        }

        // Configuration was loaded - now prepare the list of OpenFlow enabled ports

        pCore->SysIP = pCh->Inventory.NE.SysIP;

        X_List_Clear(pCore->Ports);

        X_Core_Generate_OpenFlow_Ports(pCore);

        //OF_Driver_Connect(pCore->OpenFlowChannel,pCore->OpenFlowAddr,0);

        OpenFlow_Driver_Start(pCore->OpenFlowDrv);

        OpenFlow_Driver_Connect(pCore->OpenFlowDrv,pCore->OpenFlowAddr);

    }
    else if (type == SNMP_CHANNEL_CB_CONN_DESTROYED)
    {
        X_LoadEntityConnection(pRsrc,(EntityConnection*) data,X_RES_OPER_DESTROY);
    }
    else if (type == SNMP_CHANNEL_CB_CONN_CREATED)
    {
        X_LoadEntityConnection(pRsrc,(EntityConnection*) data, X_RES_OPER_CREATE);
    }
    else if (type == SNMP_CHANNEL_CB_MOD_CREATED)
    {
        X_LoadEntityModule(pRsrc,(EntityModule*) data, X_RES_OPER_CREATE);
    }
    else if (type == SNMP_CHANNEL_CB_MOD_DESTROYED)
    {
        X_LoadEntityModule(pRsrc,(EntityModule*) data,X_RES_OPER_DESTROY);
    }
    else if (type == SNMP_CHANNEL_CB_OL_CREATED)
    {
        X_LoadEntityOL(pRsrc,(EntityOL*) data,X_RES_OPER_CREATE);
    }
    else if (type == SNMP_CHANNEL_CB_OL_DESTROYED)
    {
        X_LoadEntityOL(pRsrc,(EntityOL*) data,X_RES_OPER_DESTROY);
    }

    X_Resource_Unlock(pRsrc);
}

int
OpenFlow_Driver_Callback(OpenFlow_DriverPtr pDrv, OpenFlow_Driver_Callback_Type type, struct ofp_header *pMsg)
{
    X_CorePtr pCore;

    if (pDrv == NULL)
        return 0;

    pCore = (X_CorePtr)pDrv->UserData;

    switch (type)
    {
    case OPENFLOW_DRV_CB_FEATURES_REQ:
        X_Core_Handle_Features_Request(pCore);
        break;

    case OPENFLOW_DRV_CB_MESSAGE:
        X_Core_Handle_OpenFlow_Message(pCore, pMsg);
        break;

    case OPENFLOW_DRV_CB_DISCONNECTED:
        break;

    default:
        break;
    }

    return 0;
}

/** TL1 channel setup*/
